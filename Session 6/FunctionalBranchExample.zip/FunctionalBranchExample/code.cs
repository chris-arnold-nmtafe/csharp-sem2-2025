﻿using System;

namespace FunctionalBranchExample
{
    public class OtherOption : IConsoleThing
    {
        public void Main(string[] args)
        {
            Console.WriteLine("Some different functionality");
        }
    }
}
