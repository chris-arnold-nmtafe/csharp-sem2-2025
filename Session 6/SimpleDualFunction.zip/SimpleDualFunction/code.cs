﻿using System;

namespace SimpleDualFunction
{
    public class OtherOption
    {
        public void Main(string[] args)
        {
            Console.WriteLine("Some different functionality");
        }
    }
}
